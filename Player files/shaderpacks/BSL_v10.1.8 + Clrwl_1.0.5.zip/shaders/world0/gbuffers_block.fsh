/* 
BSL Shaders v10 Series by Capt Tatsu 
https://capttatsu.com 
*/ 

#version 120 

#extension GL_ARB_shader_texture_lod : enable

#define OVERWORLD
#define FSH

#include "/program/gbuffers_block.glsl"
